MIT License

Copyright (c) 2023 shadcn

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Motomind brand assets

The wordmark paths are sourced from https://www.motomind.co.kr/src/motomind_logo.svg (retrieved 2026-10-31). MotomindSymbol extracts the first M path, matching the official website favicon. Brand assets remain the property of Motomind; this package does not grant separate trademark rights. See docs/console-ui.md in the source repository for provenance and usage.

## Controller input prompts

Original, unmodified PNGs from JulioCacko, FREE Input Prompts Pack 1.4.
Source: https://juliocacko.itch.io/free-input-prompts
License: CC0 1.0 Universal — https://creativecommons.org/publicdomain/zero/1.0/
Imported from MotomindKR/bello_mujoco at e3d4b9ba5779ab7a8995a03dcd90016b9bd34f67, console/src/assets/input-prompts.
The 84 original files are embedded as lossless data URLs in src/lib/input-prompt-assets.ts so consumer builds require no copy step or external host. Original filenames and SHA-256 hashes are preserved in brand/input-prompts-provenance.json.
