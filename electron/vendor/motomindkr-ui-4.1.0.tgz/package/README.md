# @motomindkr/ui

React 19용 모토마인드 컴포넌트입니다. shadcn/ui Base UI 프리셋 `base-nova`를 기반으로 하며, CSS 변수로 라이트·다크 테마를 적용합니다.

## 설치

사내 GitHub Packages 인증 후 `npm install --save-exact @motomindkr/ui@4.1.0`으로 설치합니다. 개발자 인증과 소비 저장소 CI 설정은 [배포 가이드](../../docs/distribution.md)를 참고하세요.

## 가져오기

```tsx
import '@motomindkr/ui/styles.css';
import { Button } from '@motomindkr/ui/components/button';
import { Input } from '@motomindkr/ui/components/input';
import { Label } from '@motomindkr/ui/components/label';

export default function Example() {
  return (
    <div>
      <Label htmlFor="name">Name</Label>
      <Input id="name" />
      <Button>Continue</Button>
    </div>
  );
}
```

`styles.css`는 컴포넌트에 필요한 Tailwind 스타일과 테마를 포함합니다. Pretendard는 앱에서 설치하고 불러옵니다. 생략하면 시스템 글꼴을 사용합니다.

## 컴포넌트

- Actions: Button, DropdownMenu
- Inputs: Checkbox, Input, Label, RadioGroup, Select, Slider, Switch, Textarea
- Structure: Card, Collapsible, Separator, Tabs
- Navigation: NavigationMenu, Pagination
- Data: CodeBlock, Table, Trace
- Feedback: Alert, Badge, Dialog, Progress

API는 [shadcn/ui Base UI 문서](https://ui.shadcn.com/docs/components)를 따릅니다. 컴포넌트별 경로로 가져오며, DOM 속성·이벤트·ref·className을 전달할 수 있습니다. Slider는 단일 thumb에 전달된 접근성 라벨도 적용합니다.

## 테마

기본은 라이트입니다. `document.documentElement`에 `dark` 클래스를 추가하면 다크 테마를 사용합니다. 시스템 감지와 선택 저장은 앱에서 처리합니다.

색상과 radius는 `src/styles/tokens.css` 한 곳에서 관리합니다.

Tailwind 4를 이미 사용하는 앱은 `styles.css` 대신 아래처럼 구성할 수 있습니다. 앱에서 `tailwindcss`와 `tw-animate-css`를 설치하고, `@source` 경로를 CSS 파일 위치에 맞춥니다.

```css
@import 'tailwindcss';
@import 'tw-animate-css';
@import '@motomindkr/ui/theme.css';
@source '../node_modules/@motomindkr/ui/dist';
```

## 빌드

```sh
npm run build:ui
npm pack --workspace @motomindkr/ui
```

압축 파일에는 ESM, 타입 선언, 컴파일된 CSS, 테마 원본과 라이선스 고지가 포함됩니다. `use client` 지시문은 빌드 후에도 유지됩니다.

복사한 shadcn/ui 소스의 라이선스는 [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)에 보존합니다.

## Base UI 조합

기본 상호작용은 `@base-ui/react`를 사용하며 Calendar·Chart·Command 등의 공식 보조 라이브러리도 포함합니다. v2의 `asChild` 대신 Base UI의 `render`를 사용합니다. Button을 링크로 쓸 때는 `nativeButton={false}`와 `role="link"`를 지정합니다.

```tsx
<Button nativeButton={false} role="link" render={<a href="/settings" />}>
  Settings
</Button>
<DialogTrigger render={<Button variant="outline" />}>Open</DialogTrigger>
```

Select의 선택된 텍스트는 `items`로 전달합니다. 값과 라벨을 분리하면 번역이 바뀔 때 현재 선택의 표시도 갱신됩니다.

```tsx
<Select defaultValue="one" items={{ one: 'First', two: 'Second' }}>
  <SelectTrigger aria-label="Choose an item">
    <SelectValue />
  </SelectTrigger>
  <SelectContent>
    <SelectItem value="one">First</SelectItem>
    <SelectItem value="two">Second</SelectItem>
  </SelectContent>
</Select>
```

## CodeBlock

제목·헤더는 선택 사항입니다. 복사 버튼은 아이콘으로 표시합니다. `copyLabel`, `copiedLabel`로 접근성 안내를 번역할 수 있습니다.

```tsx
import {
  CodeBlock,
  CodeBlockActions,
  CodeBlockContent,
  CodeBlockCopyButton,
} from '@motomindkr/ui/components/code-block';

<CodeBlock>
  <CodeBlockActions>
    <CodeBlockCopyButton value={source} />
  </CodeBlockActions>
  <CodeBlockContent>{source}</CodeBlockContent>
</CodeBlock>;
```

하이라이팅은 선택 사항입니다. `@motomindkr/ui/hooks/use-highlighted-code`의 `useHighlightedCode(source, 'tsx')`가 반환한 각 줄을 `CodeBlockLine`으로 감쌉니다. Shiki와 언어 파일은 이 훅을 사용하는 경우에만 불러옵니다. 지원하지 않는 언어는 일반 텍스트로 표시합니다. 색상은 테마의 공통 CSS 토큰을 사용합니다.

## Alert

| variant   | 역할               |
| --------- | ------------------ |
| `default` | 중립적인 안내      |
| `info`    | 추가 정보          |
| `success` | 완료·성공          |
| `warning` | 확인이 필요한 상태 |
| `error`   | 실패·오류          |

기존 `destructive`는 `error`와 같은 스타일로 유지합니다. 아이콘·제목·설명은 필요한 부분을 조합합니다. 긴 제목은 줄바꿈됩니다.

```tsx
import { CircleCheck } from 'lucide-react';
import { Alert, AlertTitle, AlertDescription } from '@motomindkr/ui/components/alert';

<Alert variant="success" role="status">
  <CircleCheck aria-hidden="true" />
  <AlertTitle>Complete</AlertTitle>
  <AlertDescription>The operation completed.</AlertDescription>
</Alert>;
```

기본 role은 `alert`입니다. 일반 안내에는 `role="status"`를 지정할 수 있습니다.

## 상태 팔레트

`info`, `success`, `warning`, `error`마다 네 가지 색상을 정의합니다.

| 토큰                   | 용도        |
| ---------------------- | ----------- |
| `--success`            | 아이콘·강조 |
| `--success-foreground` | 제목·설명   |
| `--success-surface`    | 배경        |
| `--success-border`     | 테두리      |

다른 상태도 같은 접미사를 사용합니다. `--error`는 shadcn의 `--destructive`와 연결되어 Button·Badge의 오류 색상과 일치합니다. 라이트·다크 값을 같은 파일에서 관리하며, 예제 사이트의 Colors 페이지에서 확인할 수 있습니다.

## Badge

`info`, `success`, `warning`, `error`는 Alert와 같은 상태 팔레트를 사용합니다. `destructive`는 `error`의 별칭입니다. 기존 `default`, `secondary`, `outline`, `ghost`, `link`도 유지합니다.

```tsx
import { CircleCheck } from 'lucide-react';
import { Badge } from '@motomindkr/ui/components/badge';

<Badge variant="success">
  <CircleCheck aria-hidden="true" />
  Complete
</Badge>;
```

## 전체 컴포넌트와 언어

base-nova 기본 UI 전체와 Motomind 조합을 제공합니다. 분류는 저장소의 `.shadcn/config.json`, 사용 예제는 `apps/showcase/src/examples`를 참고하세요.

```tsx
import { UIProvider } from '@motomindkr/ui/components/ui-provider';
<UIProvider locale="ko">{/* 앱 */}</UIProvider>;
```

DatePicker는 Date 값, TimePicker는 HH:mm 문자열의 `value/defaultValue/onValueChange`를 사용합니다. Sidebar는 SidebarProvider와 조합합니다. Drawer는 `swipeDirection`으로 방향을 지정하며 단순 측면 패널은 Sheet를 사용합니다. Toaster는 공식 provider를 포함하므로 기존 ToastProvider 안에 다시 중첩하지 않습니다.
